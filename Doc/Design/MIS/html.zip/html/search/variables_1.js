var searchData=
[
  ['delay',['delay',['../namespace_d_n_a___says.html#a71a53f3e5855e80bac06da13a1426ed9',1,'DNA_Says']]]
];
