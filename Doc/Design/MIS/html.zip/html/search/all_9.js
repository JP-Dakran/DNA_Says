var searchData=
[
  ['orange',['orange',['../namespace_d_n_a___says.html#a4dde2a66831522267e0d6a00e6ab715f',1,'DNA_Says']]]
];
