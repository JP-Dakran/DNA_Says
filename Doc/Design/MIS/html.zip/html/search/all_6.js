var searchData=
[
  ['jp',['jp',['../namespace_d_n_a___says.html#a726901c2304cb7d0bf69444a788404ab',1,'DNA_Says']]]
];
