var searchData=
[
  ['changebackgroundanimation',['changeBackgroundAnimation',['../namespace_d_n_a___says.html#ab34c76c889a6f2a52e65115c552fdd3f',1,'DNA_Says']]],
  ['checkforquit',['checkForQuit',['../namespace_d_n_a___says.html#ab5262e6232b2a8d7ec33d485fec1a52a',1,'DNA_Says']]]
];
