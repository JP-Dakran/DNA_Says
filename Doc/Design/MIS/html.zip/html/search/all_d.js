var searchData=
[
  ['update',['update',['../namespace_d_n_a___says.html#a6cd0efa23eaa647a0b2bdfc042a7eacc',1,'DNA_Says']]]
];
