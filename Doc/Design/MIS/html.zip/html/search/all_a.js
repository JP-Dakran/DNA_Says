var searchData=
[
  ['red',['red',['../namespace_d_n_a___says.html#ace4965e499eca524767fb5f59bc6a189',1,'DNA_Says']]]
];
