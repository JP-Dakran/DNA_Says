var searchData=
[
  ['fps',['fps',['../namespace_d_n_a___says.html#a17b8938a6ffd69ba0f9be6737a2e76b1',1,'DNA_Says']]]
];
