var searchData=
[
  ['dna_5fsays',['DNA_Says',['../class_d_n_a___says_1_1_d_n_a___says.html',1,'DNA_Says']]]
];
