var searchData=
[
  ['indigo',['indigo',['../namespace_d_n_a___says.html#a145382324d0571526baa80b8db4265ee',1,'DNA_Says']]]
];
