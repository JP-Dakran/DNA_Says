var searchData=
[
  ['main',['Main',['../index.html',1,'']]],
  ['main',['main',['../namespace_d_n_a___says.html#a11341065fcc9073f6e4bfebf5c3f64fa',1,'DNA_Says']]],
  ['menu',['menu',['../namespace_d_n_a___says.html#a08fb033edfbce6a3b481bcfea5791296',1,'DNA_Says']]]
];
