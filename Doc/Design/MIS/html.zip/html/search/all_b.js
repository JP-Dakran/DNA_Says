var searchData=
[
  ['setup',['setup',['../namespace_d_n_a___says.html#ab3102f43b1c4989e73c71d43f6281d88',1,'DNA_Says']]],
  ['shady',['shady',['../namespace_d_n_a___says.html#aa4e75af187f782e5d11d660cd3d6ee9b',1,'DNA_Says']]],
  ['showgoback',['showGoBack',['../namespace_d_n_a___says.html#a43a0d2688f8f591138b0a2ae73fdb307',1,'DNA_Says']]],
  ['showinst',['showInst',['../namespace_d_n_a___says.html#ad0fc2ef4646e97ddb79c3cb1911aaa7a',1,'DNA_Says']]],
  ['showscore',['showScore',['../namespace_d_n_a___says.html#a20153fdc35d7d034bf29951017f0d494',1,'DNA_Says']]]
];
