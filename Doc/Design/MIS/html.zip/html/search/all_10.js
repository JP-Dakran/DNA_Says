var searchData=
[
  ['yellow',['yellow',['../namespace_d_n_a___says.html#a58359ed5ec35a715d44b38f434102c92',1,'DNA_Says']]]
];
