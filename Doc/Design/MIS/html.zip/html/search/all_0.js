var searchData=
[
  ['bgcolor',['bgColor',['../namespace_d_n_a___says.html#a0643b6b53caa0e8d31978f3d6059a720',1,'DNA_Says']]],
  ['black',['black',['../namespace_d_n_a___says.html#a7f13339aedd29395334ca751ad6d67bb',1,'DNA_Says']]],
  ['blue',['blue',['../namespace_d_n_a___says.html#a1a74716224f332c6bdf0c5d3daaa7201',1,'DNA_Says']]],
  ['brightblue',['brightBlue',['../namespace_d_n_a___says.html#afee2d204370379909a4fca9df8e7c395',1,'DNA_Says']]],
  ['brightgreen',['brightGreen',['../namespace_d_n_a___says.html#ad587aae86fa1b241d0e8a1ac6a3ee6e9',1,'DNA_Says']]],
  ['brightindigo',['brightIndigo',['../namespace_d_n_a___says.html#a405a7e9bac3fb44043806dc57ea730a1',1,'DNA_Says']]],
  ['brightorange',['brightOrange',['../namespace_d_n_a___says.html#aa1d8fe01295ad0ac998f92151579a406',1,'DNA_Says']]],
  ['brightred',['brightRed',['../namespace_d_n_a___says.html#aea1a2aca0ceebb07c9299227681982c4',1,'DNA_Says']]],
  ['brightviolet',['brightViolet',['../namespace_d_n_a___says.html#a1e73f2d28d81264f1e58089b5d549a9c',1,'DNA_Says']]],
  ['brightyellow',['brightYellow',['../namespace_d_n_a___says.html#a29b960b1c225efcc1d9fdd787e9326eb',1,'DNA_Says']]]
];
