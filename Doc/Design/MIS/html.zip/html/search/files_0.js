var searchData=
[
  ['dna_5fsays_2epy',['DNA_Says.py',['../_d_n_a___says_8py.html',1,'']]]
];
