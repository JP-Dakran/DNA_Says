var searchData=
[
  ['violet',['violet',['../namespace_d_n_a___says.html#a291834fcc3a7335be5b3b6bb0e64d025',1,'DNA_Says']]]
];
