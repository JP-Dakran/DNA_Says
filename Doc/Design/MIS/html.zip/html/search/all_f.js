var searchData=
[
  ['white',['white',['../namespace_d_n_a___says.html#a3d1435fc3ba32cf4b3eee52e53e00913',1,'DNA_Says']]],
  ['winheight',['winHeight',['../namespace_d_n_a___says.html#afef3e5656b8ea1209361c233b24b0b47',1,'DNA_Says']]],
  ['winwidth',['winWidth',['../namespace_d_n_a___says.html#affb7bca8414e984254cc9e77cc03ce49',1,'DNA_Says']]]
];
